package org.moreno.cristian.modelos;

public class Ensayo extends Publicacion {
    private String id;
    private String tema;

    // Constructor

    public Ensayo(String id, String titulo, int totalEjemplares, int ejemplaresPrestados, int ejemplaresDisponibles, Autor autor, String id1, String tema) {
        super(id, titulo, totalEjemplares, ejemplaresPrestados, ejemplaresDisponibles, autor);
        this.id = id1;
        this.tema = tema;
    }

    public Ensayo(String titulo, int totalEjemplares, int ejemplaresDisponibles, int ejemplaresPrestados, Autor autor, String id, String tema) {
        super(titulo, totalEjemplares, ejemplaresDisponibles, ejemplaresPrestados, autor);
        this.id = id;
        this.tema = tema;
    }


    // Getters y setters

    @Override
    public String getId() {
        return id;
    }

    @Override
    public void setId(String id) {
        this.id = id;
    }


    public String getTema() {
        return tema;
    }

    public void setTema(String tema) {
        this.tema = tema;
    }
}

