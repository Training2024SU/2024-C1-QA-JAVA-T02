package org.moreno.cristian.modelos.enums;

public enum AreaConocimiento {

    CIENCIA_POPULAR,
    HISTORIA,
    BIOGRAFIAS,
    ECONOMIA

}
