package org.moreno.cristian.ui;

import com.mysql.cj.jdbc.ConnectionImpl;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.moreno.cristian.modelos.Usuario;
import org.moreno.cristian.servicios.ScannerUtil;
import org.moreno.cristian.repositorios.RepositorioPrestamo;
import org.moreno.cristian.servicios.ServicioPruebasPrestamo;
import org.moreno.cristian.servicios.ServicioUsuario;
import java.util.*;
import org.moreno.cristian.servicios.ConexionBD;

import org.moreno.cristian.modelos.enums.Rol;
import org.moreno.cristian.servicios.ServicioPrestamo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import static org.moreno.cristian.servicios.ConexionBD.obtenerConexion;



public class MenuSuperusuario {
    public static class ScannerUtil {
        public static Scanner scanner = new Scanner(System.in);

        public static Scanner obtenerScanner() {
            return scanner;
        }
    }


    private static final Scanner scan = ScannerUtil.obtenerScanner();
    private static final ServicioUsuario servicioUsuario = new ServicioUsuario();
    private static final Logger log = LogManager.getLogger(MenuSuperusuario.class);
    private static final ServicioPruebasPrestamo servicioPruebasPrestamo = new ServicioPruebasPrestamo();


    public static void home(Usuario superusuario) {
        while (true) {
            log.info("\n¿Qué deseas hacer?\n" +
                    "   1. Crear administrador \n" +
                    "   2. Ver Usuarios \n" +
                    "   3. Registrar préstamo \n" +
                    "   4. Ver préstamos \n" +
                    "   5. Restaurar sistema \n" +
                    "   6. Salir \n" +
                    "Ingresa el número de la opción deseada:");

            String respuestaSuperusuario = scan.nextLine();

            switch (respuestaSuperusuario) {
                case "1":
                    crearAdministrador();
                    break;
                case "2":
                    verListaUsuarios();
                    break;
                case "3":
                    guardarPrestamo();
                    break;
                case "4":
                    mostrarListaPrestamos();
                    break;
                case "5":
                    restaurarEstadoInicial();
                    break;
                case "6":
                    return;
                default:
                    log.error("Inténtalo de nuevo");
            }
        }
    }


    private static void crearAdministrador() {
        while (true) {
            System.out.print("Ingresa nombre del nuevo administrador: ");
            String nombreAdmin = scan.nextLine();
            System.out.print("Ingresa correo del nuevo administrador: ");
            String correoAdmin = scan.nextLine();
            System.out.print("Ingresa contraseña del nuevo administrador: ");
            String contraseniaAdmin = scan.nextLine();

            if (!nombreAdmin.isEmpty() && !correoAdmin.isEmpty() && !contraseniaAdmin.isEmpty()) {
                Usuario nuevoAdmin = new Usuario(nombreAdmin, correoAdmin, contraseniaAdmin, Rol.ADMIN);
                servicioUsuario.guardarUsuario(nuevoAdmin);
                log.info("\nAdministrador creado exitosamente\n");
                break;
            } else {
                log.warn("Por favor, ingresa todos los datos correctamente.");
            }
        }
    }

    private static void verListaUsuarios() {
        System.out.println("\nLista de usuarios:");
        servicioUsuario.listarUsuarios().ifPresentOrElse(
                usuarios -> usuarios.forEach(usuario -> System.out.println(usuario)),
                () -> System.out.println("No hay usuarios registrados.")
        );
    }

    public static void guardarPrestamo() {
        try {
            // Obtener conexión a la base de datos
            Connection connection = ConexionBD.obtenerConexion();

            // Pedir información al usuario
            Scanner scanner = new Scanner(System.in);
            System.out.println("Ingrese el ID del préstamo:");
            String idPrestamo = scanner.nextLine();
            System.out.println("Ingrese el ID de la publicación:");
            String idPublicacion = scanner.nextLine();

            // Consulta para obtener la información de la publicación
            String sql = "SELECT * FROM publicacion WHERE id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, idPublicacion);
            ResultSet resultSet = statement.executeQuery();

            // Verificar si se encontró la publicación
            if (resultSet.next()) {
                // Mostrar la información de la publicación
                System.out.println("Información de la publicación:");
                System.out.println("ID: " + resultSet.getString("id"));
                System.out.println("Título: " + resultSet.getString("titulo"));
                System.out.println("Número de ejemplares: " + resultSet.getInt("nEjemplares"));
                System.out.println("Número de ejemplares prestados: " + resultSet.getInt("nPrestados"));
                System.out.println("Autor ID: " + resultSet.getString("autor_id"));

                // Solicitar la cantidad de ejemplares a prestar
                System.out.println("Ingrese la cantidad de ejemplares que desea prestar:");
                int cantidadPrestamo = scanner.nextInt();
                scanner.nextLine(); // Consumir la nueva línea
                System.out.println("Cantidad de ejemplares a prestar: " + cantidadPrestamo);

                // Actualizar el estado del préstamo en la tabla publicacion
                String updateSql = "UPDATE publicacion SET nPrestados = nPrestados + ? WHERE id = ?";
                PreparedStatement updateStatement = connection.prepareStatement(updateSql);
                updateStatement.setInt(1, cantidadPrestamo);
                updateStatement.setString(2, idPublicacion);
                updateStatement.executeUpdate();

                System.out.println("Su solicitud ha sido recibida, cuenta con 3 días hábiles para retirar la publicación");
            } else {
                System.out.println("No se encontró ninguna publicación con el ID proporcionado.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void mostrarListaPrestamos() {
        try {
            // Obtener conexión a la base de datos
            Connection connection = ConexionBD.obtenerConexion();

            // Consulta SQL para obtener la lista de préstamos con todos los detalles
            String sql = "SELECT * FROM prestamo";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();

            // Mostrar la lista de préstamos con todos los detalles
            System.out.println("Lista de préstamos:");
            while (resultSet.next()) {
                System.out.println("ID del préstamo: " + resultSet.getString("id"));
                System.out.println("ID del usuario: " + resultSet.getString("usuario_id"));
                System.out.println("Fecha realizado: " + resultSet.getDate("fechaRealizado"));
                System.out.println("Fecha expiración: " + resultSet.getDate("fechaExpiracion"));
                System.out.println("Estado: " + resultSet.getString("estado"));
                System.out.println("---------------------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void restaurarEstadoInicial() {
        try {
            // Obtener conexión a la base de datos
            Connection connection = ConexionBD.obtenerConexion();

            // Eliminar registros de la tabla 'publicacionxprestamo'
            String sqlDeletePublicacionxPrestamo = "DELETE FROM publicacionxprestamo";
            PreparedStatement deleteStatement = connection.prepareStatement(sqlDeletePublicacionxPrestamo);
            deleteStatement.executeUpdate();

            // Restaurar el estado inicial de la tabla 'publicacion' (eliminar todos los registros)
            String sqlDeletePublicacion = "DELETE FROM publicacion";
            PreparedStatement deletePublicacionStatement = connection.prepareStatement(sqlDeletePublicacion);
            deletePublicacionStatement.executeUpdate();

            // Restaurar el estado inicial de la tabla 'prestamo' (eliminar todos los registros)
            String sqlDeletePrestamo = "DELETE FROM prestamo";
            PreparedStatement deletePrestamoStatement = connection.prepareStatement(sqlDeletePrestamo);
            deletePrestamoStatement.executeUpdate();

            // Mensaje de éxito
            System.out.println("El programa ha sido restaurado a su estado inicial.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}

