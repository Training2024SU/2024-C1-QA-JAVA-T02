package org.moreno.cristian.modelos.enums;

public enum Rol {
    ADMIN,
    ASISTENTE,
    LECTOR,
    SUPERUSUARIO
}


