package org.moreno.cristian.modelos.enums;

public enum Genero {
    HISTORICA,
    TERROR,
    CIENCIA_FICCION,
    ROMANTICA
}
