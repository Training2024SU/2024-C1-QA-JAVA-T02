package org.moreno.cristian.ui;

public class MenuFunciones {

    public static void crearAsistente() {

    }

    public static void crearSuperusuario() {

    }

    public static void mostrarUsuarios() {

    }



    //  Libros
    public static void crearPublicacion() {

    }
}
