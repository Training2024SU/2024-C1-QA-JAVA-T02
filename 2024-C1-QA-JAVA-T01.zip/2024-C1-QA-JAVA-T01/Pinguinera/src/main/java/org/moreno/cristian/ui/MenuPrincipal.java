package org.moreno.cristian.ui;

import org.moreno.cristian.modelos.Usuario;
import org.moreno.cristian.servicios.ScannerUtil;
import org.moreno.cristian.servicios.ServicioUsuario;


import java.util.Optional;
import java.util.Scanner;

public class MenuPrincipal {

    private static Scanner scan = ScannerUtil.obtenerScanner();
    private static final ServicioUsuario servicioUsuario = new ServicioUsuario();

    public static void menuInicial() {
        while (true) {
            System.out.println("\n¿Qué deseas hacer?\n" +
                    "   1. Iniciar sesión \n" +
                    "   2. Registrarme \n" +
                    "   3. Cambiar contraseña \n" +
                    "   4. Cambiar nombre \n" +
                    "   5. Cambiar correo \n" +
                    "   6. Salir \n");

            String respuestaUsuario = scan.nextLine();

            switch(respuestaUsuario) {
                case "1":
                    inicioSesion();
                    break;
                case "2":
                    registroUsuario();
                    break;
                case "3":
                    cambiarContrasenia();
                    break;
                case "4":
                    cambiarNombre();
                    break;
                case "5":
                    cambiarCorreo();
                    break;
                case "6":
                    return;
                default:
                    System.out.println("Respuesta no válida");
            }
        }
    }

    public static void inicioSesion () {

        while (true) {

            System.out.print("Ingresa tu correo: ");
            String correoUsuario = scan.nextLine();

            System.out.print("Ingresa tu contraseña: ");
            String contraseniaUsuario = scan.nextLine();

            Optional<Usuario> usuarioDb = servicioUsuario.validarCredenciales(correoUsuario, contraseniaUsuario);
            if (usuarioDb.isPresent()) {

                System.out.println("Bienvenido " + usuarioDb.get().getNombre() + " a tu perfil " + usuarioDb.get().getRol() + "\n");
                switch(usuarioDb.get().getRol()) {
                    case LECTOR:
                        MenuLector.home(usuarioDb.get());
                        break;
                    case ADMIN:
                        MenuAdmin.home(usuarioDb.get());
                        break;
                    case ASISTENTE:
                        MenuAsistente.home(usuarioDb.get());
                        break;
                    case SUPERUSUARIO:
                        MenuSuperusuario.home(usuarioDb.get());
                        break;

                }
            } else {
                System.out.println("Correo o contraseña erróneos, inténtalo de nuevo");
            }
        }
    }

    public static void registroUsuario() {

        while (true) {

            System.out.print("Ingresa tu nombre: ");
            String nombreUsuario = scan.nextLine();
            System.out.print("Ingresa tu correo: ");
            String correoUsuario = scan.nextLine();
            System.out.print("Ingresa tu contraseña: ");
            String contraseniaUsuario = scan.nextLine();

            if (!nombreUsuario.isEmpty() && !correoUsuario.isEmpty() && !contraseniaUsuario.isEmpty()) {
                // Si ninguno de los campos está vacío
                Usuario newUser = new Usuario(nombreUsuario, correoUsuario, contraseniaUsuario);
                servicioUsuario.guardarUsuario(newUser);
                System.out.println("\nUsuario guardado\n");
                break; // Salir del bucle
            } else {
                System.out.println("Por favor, ingresa todos los datos correctamente.");
            }

        }
    }

    public static void cambiarContrasenia() {
        System.out.print("Ingrese su correo electrónico: ");
        String correo = scan.nextLine();
        System.out.print("Ingrese su contraseña actual: ");
        String contraseniaActual = scan.nextLine();
        System.out.print("Ingrese su nueva contraseña: ");
        String nuevaContrasenia = scan.nextLine();

        servicioUsuario.cambiarContrasenia(correo, contraseniaActual, nuevaContrasenia);
        System.out.println("¡Contraseña cambiada exitosamente!");
    }

    public static void cambiarNombre() {
        System.out.print("Ingrese su correo electrónico: ");
        String correo = scan.nextLine();
        System.out.print("Ingrese su nuevo nombre: ");
        String nuevoNombre = scan.nextLine();

        Optional<Usuario> usuarioDb = servicioUsuario.buscarPorCorreo(correo);
        if (usuarioDb.isPresent()) {
            servicioUsuario.cambiarNombre(correo, nuevoNombre);
            System.out.println("¡Nombre cambiado exitosamente!");
        } else {
            System.out.println("No se encontró ningún usuario con ese correo.");
        }
    }

    public static void cambiarCorreo() {
        System.out.print("Ingrese su correo electrónico actual: ");
        String correoActual = scan.nextLine();
        System.out.print("Ingrese su nueva correo electrónico: ");
        String nuevoCorreo = scan.nextLine();

        Optional<Usuario> usuarioDb = servicioUsuario.buscarPorCorreo(correoActual);
        if (usuarioDb.isPresent()) {
            servicioUsuario.cambiarCorreo(correoActual, nuevoCorreo);
            System.out.println("¡Correo electrónico cambiado exitosamente!");
        } else {
            System.out.println("No se encontró ningún usuario con ese correo.");
        }
    }
}
