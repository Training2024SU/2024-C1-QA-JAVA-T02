package org.moreno.cristian.servicios;

import org.moreno.cristian.modelos.Autor;
import org.moreno.cristian.modelos.Videograbacion;
import org.moreno.cristian.repositorios.RepositorioVideograbacion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ServicioVideograbacion implements RepositorioVideograbacion {

    private final Connection conn;

    public ServicioVideograbacion(Connection conn) {
        this.conn = conn;
    }

    @Override
    public Optional<List<Videograbacion>> todasVideograbaciones() {
        List<Videograbacion> videograbaciones = new ArrayList<>();
        String sql = "SELECT * FROM videograbacion";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                // Process each row as needed
                Videograbacion videograbacion = construirVideograbacionDesdeResultSet(rs);
                videograbaciones.add(videograbacion);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.of(videograbaciones);
    }

    @Override
    public Optional<List<Videograbacion>> todasVideograbacionesPorAutor(String autor) {
        List<Videograbacion> videograbaciones = new ArrayList<>();
        String sql = "SELECT * FROM videograbacion WHERE autor = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, autor);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                // Process each row as needed
                Videograbacion videograbacion = construirVideograbacionDesdeResultSet(rs);
                videograbaciones.add(videograbacion);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.of(videograbaciones);
    }

    @Override
    public Optional<Videograbacion> videograbacionesPorTitulo(String titulo) {
        String sql = "SELECT * FROM videograbacion WHERE titulo = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, titulo);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                // Process the result set
                Videograbacion videograbacion = construirVideograbacionDesdeResultSet(rs);
                return Optional.of(videograbacion);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }

    @Override
    public Optional<List<Videograbacion>> videograbacionesDisponiblesPorTitulo(String tituloVideograbacion) {
        List<Videograbacion> videograbaciones = new ArrayList<>();
        String sql = "SELECT * FROM videograbacion WHERE titulo = ? AND ejemplaresDisponibles > 0";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, tituloVideograbacion);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                // Process each row as needed
                Videograbacion videograbacion = construirVideograbacionDesdeResultSet(rs);
                videograbaciones.add(videograbacion);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.of(videograbaciones);
    }

    @Override
    public Optional<List<Videograbacion>> videograbacionesDisponiblesPorAutor(String nombreAutor) {
        List<Videograbacion> videograbaciones = new ArrayList<>();
        String sql = "SELECT * FROM videograbacion WHERE autor = ? AND ejemplaresDisponibles > 0";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, nombreAutor);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                // Process each row as needed
                Videograbacion videograbacion = construirVideograbacionDesdeResultSet(rs);
                videograbaciones.add(videograbacion);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.of(videograbaciones);
    }

    @Override
    public boolean guardarVideograbacion(Videograbacion nuevaVideograbacion) {
        String sql = "INSERT INTO videograbacion (id, titulo, totalEjemplares, ejemplaresPrestados, ejemplaresDisponibles, autor, duracion, formato) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, nuevaVideograbacion.getId());
            pstmt.setString(2, nuevaVideograbacion.getTitulo());
            pstmt.setInt(3, nuevaVideograbacion.getTotalEjemplares());
            pstmt.setInt(4, nuevaVideograbacion.getEjemplaresPrestados());
            pstmt.setInt(5, nuevaVideograbacion.getEjemplaresDisponibles());
            pstmt.setString(6, nuevaVideograbacion.getAutor().getId());
            pstmt.setInt(7, nuevaVideograbacion.getDuracion());
            pstmt.setString(8, nuevaVideograbacion.getFormato());

            int filasAfectadas = pstmt.executeUpdate();

            return filasAfectadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean eliminarVideograbacion(String tituloVideograbacion) {
        String sql = "DELETE FROM videograbacion WHERE titulo = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, tituloVideograbacion);
            int filasAfectadas = pstmt.executeUpdate();
            return filasAfectadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean actualizarVideograbacion(Videograbacion videograbacion) {
        String sql = "UPDATE videograbacion SET titulo = ?, totalEjemplares = ?, ejemplaresPrestados = ?, ejemplaresDisponibles = ?, autor = ?, duracion = ?, formato = ? WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, videograbacion.getTitulo());
            pstmt.setInt(2, videograbacion.getTotalEjemplares());
            pstmt.setInt(3, videograbacion.getEjemplaresPrestados());
            pstmt.setInt(4, videograbacion.getEjemplaresDisponibles());
            pstmt.setString(5, videograbacion.getAutor().getId());
            pstmt.setInt(6, videograbacion.getDuracion());
            pstmt.setString(7, videograbacion.getFormato());
            pstmt.setString(8, videograbacion.getId());

            int filasAfectadas = pstmt.executeUpdate();

            return filasAfectadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private Videograbacion construirVideograbacionDesdeResultSet(ResultSet rs) throws SQLException {
        String id = rs.getString("id");
        String titulo = rs.getString("titulo");
        int totalEjemplares = rs.getInt("totalEjemplares");
        int ejemplaresPrestados = rs.getInt("ejemplaresPrestados");
        int ejemplaresDisponibles = rs.getInt("ejemplaresDisponibles");
        String autorId = rs.getString("autor");
        int duracion = rs.getInt("duracion");
        String formato = rs.getString("formato");
        Autor autor = new Autor(autorId);
        return new Videograbacion(id, titulo, totalEjemplares, ejemplaresPrestados, ejemplaresDisponibles, autor, duracion, formato);
    }
}
