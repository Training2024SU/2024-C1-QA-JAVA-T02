package org.moreno.cristian.servicios;

import org.moreno.cristian.modelos.Autor;
import org.moreno.cristian.modelos.Ensayo;
import org.moreno.cristian.repositorios.RepositorioEnsayo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ServicioEnsayo implements RepositorioEnsayo {

    private final Connection conn;

    public ServicioEnsayo(Connection conn) {
        this.conn = conn;
    }

    @Override
    public Optional<List<Ensayo>> todasEnsayo() {
        List<Ensayo> ensayos = new ArrayList<>();
        String sql = "SELECT * FROM ensayo";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                // Process each row as needed
                Ensayo ensayo = construirEnsayoDesdeResultSet(rs);
                ensayos.add(ensayo);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.of(ensayos);
    }

    @Override
    public Optional<List<Ensayo>> todasEnsayoPorAutor(String autor) {
        List<Ensayo> ensayos = new ArrayList<>();
        String sql = "SELECT * FROM ensayo WHERE autor = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, autor);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                // Process each row as needed
                Ensayo ensayo = construirEnsayoDesdeResultSet(rs);
                ensayos.add(ensayo);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.of(ensayos);
    }

    @Override
    public Optional<Ensayo> ensayoPorTitulo(String titulo) {
        String sql = "SELECT * FROM ensayo WHERE titulo = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, titulo);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                // Process the result set
                Ensayo ensayo = construirEnsayoDesdeResultSet(rs);
                return Optional.of(ensayo);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }

    @Override
    public Optional<List<Ensayo>> ensayoDisponiblePorTitulo(String tituloEnsayo) {
        // This method might not be applicable for essays, but you can adjust it according to your needs
        List<Ensayo> ensayos = new ArrayList<>();
        String sql = "SELECT * FROM ensayo WHERE titulo = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, tituloEnsayo);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                // Process each row as needed
                Ensayo ensayo = construirEnsayoDesdeResultSet(rs);
                ensayos.add(ensayo);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.of(ensayos);
    }

    @Override
    public Optional<List<Ensayo>> ensayoDisponiblePorAutor(String nombreAutor) {
        // This method might not be applicable for essays, but you can adjust it according to your needs
        List<Ensayo> ensayos = new ArrayList<>();
        String sql = "SELECT * FROM ensayo WHERE autor = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, nombreAutor);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                // Process each row as needed
                Ensayo ensayo = construirEnsayoDesdeResultSet(rs);
                ensayos.add(ensayo);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.of(ensayos);
    }

    @Override
    public boolean guardarEnsayo(Ensayo nuevaEnsayo) {
        String sql = "INSERT INTO ensayo (id, titulo, totalEjemplares, ejemplaresPrestados, ejemplaresDisponibles, autor, tema) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, nuevaEnsayo.getId());
            pstmt.setString(2, nuevaEnsayo.getTitulo());
            pstmt.setInt(3, nuevaEnsayo.getTotalEjemplares());
            pstmt.setInt(4, nuevaEnsayo.getEjemplaresPrestados());
            pstmt.setInt(5, nuevaEnsayo.getEjemplaresDisponibles());
            pstmt.setString(6, nuevaEnsayo.getAutor().getId()); // Assuming the author's ID is needed here
            pstmt.setString(7, nuevaEnsayo.getTema());

            int filasAfectadas = pstmt.executeUpdate();

            return filasAfectadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean eliminarEnsayo(String tituloEnsayo) {
        String sql = "DELETE FROM ensayo WHERE titulo = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, tituloEnsayo);
            int filasAfectadas = pstmt.executeUpdate();
            return filasAfectadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean actualizarEnsayo(Ensayo ensayo) {
        String sql = "UPDATE ensayo SET totalEjemplares = ?, ejemplaresPrestados = ?, ejemplaresDisponibles = ?, autor = ?, tema = ? WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, ensayo.getTotalEjemplares());
            pstmt.setInt(2, ensayo.getEjemplaresPrestados());
            pstmt.setInt(3, ensayo.getEjemplaresDisponibles());
            pstmt.setString(4, ensayo.getAutor().getId()); // Assuming the author's ID is needed here
            pstmt.setString(5, ensayo.getTema());
            pstmt.setString(6, ensayo.getId());

            int filasAfectadas = pstmt.executeUpdate();
            return filasAfectadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private Ensayo construirEnsayoDesdeResultSet(ResultSet rs) throws SQLException {
        // Assuming you have a method to build an Ensayo object from a ResultSet
        // This method will depend on your specific implementation
        return null;
    }
}
