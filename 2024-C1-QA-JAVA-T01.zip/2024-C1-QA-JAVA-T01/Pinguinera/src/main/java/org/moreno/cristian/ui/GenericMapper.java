package org.moreno.cristian.ui;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;

public class GenericMapper {
    private static ObjectMapper jsonMapper = new ObjectMapper();
    private static XmlMapper xmlMapper = new XmlMapper();
    private static Logger logger = LoggerFactory.getLogger(GenericMapper.class);

    public static <T> T deserialize(String data, Class<T> type) {
        if (data == null) {
            return null;
        }

        try {
            return jsonMapper.readValue(data, type);
        } catch (IOException e) {
            logger.error("Error en el proceso de deserialización. Detalles: " + e.getMessage());
            return null;
        }
    }

    public static <T> String serialize(T object) {
        if (object == null) {
            return null;
        }

        try {
            return jsonMapper.writeValueAsString(object);
        } catch (JsonProcessingException e) {
            logger.error("Error en el proceso de serialización. Detalles: " + e.getMessage());
            return null;
        }
    }

    public static <T> String serializeToXML(T object) {
        if (object == null) {
            return null;
        }

        try {
            return xmlMapper.writeValueAsString(object);
        } catch (JsonProcessingException e) {
            logger.error("Error en el proceso de serialización XML. Detalles: " + e.getMessage());
            return null;
        }
    }

    public static <T> T deserializeFromXML(String xml, Class<T> type) {
        if (xml == null) {
            return null;
        }

        try {
            return xmlMapper.readValue(xml, type);
        } catch (IOException e) {
            logger.error("Error en el proceso de deserialización XML. Detalles: " + e.getMessage());
            return null;
        }
    }
}
