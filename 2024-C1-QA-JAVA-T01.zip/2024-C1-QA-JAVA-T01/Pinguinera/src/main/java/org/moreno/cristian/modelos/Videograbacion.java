package org.moreno.cristian.modelos;

import com.github.javafaker.Faker;

public class Videograbacion extends Publicacion {
    private String id;
    private int duracion;
    private String formato;

    public Videograbacion(String id, String titulo, int totalEjemplares, int ejemplaresPrestados, int ejemplaresDisponibles, Autor autor, int duracion, String formato) {
        super(id, titulo, totalEjemplares, ejemplaresDisponibles, ejemplaresPrestados, autor);
        this.id = id;
        this.duracion = duracion;
        this.formato = formato;
    }

    public Videograbacion(String titulo, int totalEjemplares, int ejemplaresPrestados, int ejemplaresDisponibles, Autor autor, int duracion, String formato) {
        super(new Faker().bothify("#####"), titulo, totalEjemplares, ejemplaresDisponibles, ejemplaresPrestados, autor);
        this.id = super.getId();
        this.duracion = duracion;
        this.formato = formato;
    }


    @Override
    public String getId() {
        return id;
    }

    @Override
    public void setId(String id) {
        this.id = id;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    public String getFormato() {
        return formato;
    }

    public void setFormato(String formato) {
        this.formato = formato;
    }
}
