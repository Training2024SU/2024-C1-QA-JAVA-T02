package org.moreno.cristian.handlers;

import org.moreno.cristian.ui.GenericMapper;

import java.io.*;
import java.nio.charset.StandardCharsets;

public class XMLInventoryHandler {

    // Método para guardar el inventario en un archivo XML
    public static <T> void guardarInventario(T inventario, String rutaArchivo) {
        String xml = GenericMapper.serialize(inventario);
        try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(rutaArchivo), StandardCharsets.UTF_8))) {
            writer.write(xml);
        } catch (IOException e) {
            System.err.println("Error al guardar el inventario en el archivo XML: " + e.getMessage());
        }
    }

    // Método para cargar el inventario desde un archivo XML
    public static <T> T cargarInventario(String rutaArchivo, Class<T> tipoInventario) {
        StringBuilder xmlBuilder = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(rutaArchivo), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                xmlBuilder.append(line);
            }
            String xml = xmlBuilder.toString();
            return GenericMapper.deserialize(xml, tipoInventario);
        } catch (IOException e) {
            System.err.println("Error al cargar el inventario desde el archivo XML: " + e.getMessage());
            return null;
        }
    }
}
