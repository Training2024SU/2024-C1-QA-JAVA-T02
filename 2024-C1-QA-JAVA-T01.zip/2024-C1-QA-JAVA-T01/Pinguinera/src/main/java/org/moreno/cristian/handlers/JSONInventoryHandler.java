package org.moreno.cristian.handlers;

import org.moreno.cristian.ui.GenericMapper;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class JSONInventoryHandler {

    // Método para guardar el inventario en un archivo JSON
    public static <T> void guardarInventario(T inventario, String rutaArchivo) {
        String json = GenericMapper.serialize(inventario);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaArchivo))) {
            writer.write(json);
        } catch (IOException e) {
            System.err.println("Error al guardar el inventario en el archivo JSON: " + e.getMessage());
        }
    }

    // Método para cargar el inventario desde un archivo JSON
    public static <T> T cargarInventario(String rutaArchivo, Class<T> tipoInventario) {
        StringBuilder jsonBuilder = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(rutaArchivo))) {
            String line;
            while ((line = reader.readLine()) != null) {
                jsonBuilder.append(line);
            }
            String json = jsonBuilder.toString();
            return GenericMapper.deserialize(json, tipoInventario);
        } catch (IOException e) {
            System.err.println("Error al cargar el inventario desde el archivo JSON: " + e.getMessage());
            return null;
        }
    }
}
