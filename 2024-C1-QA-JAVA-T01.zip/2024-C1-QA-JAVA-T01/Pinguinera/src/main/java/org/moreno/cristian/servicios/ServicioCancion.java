package org.moreno.cristian.servicios;

import org.moreno.cristian.modelos.Autor;
import org.moreno.cristian.modelos.Cancion;
import org.moreno.cristian.repositorios.RepositorioCancion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ServicioCancion implements RepositorioCancion {

    private final Connection conn;

    public ServicioCancion(Connection conn) {
        this.conn = conn;
    }

    @Override
    public Optional<List<Cancion>> todasCancion() {
        List<Cancion> canciones = new ArrayList<>();
        String sql = "SELECT * FROM cancion";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                // Process each row as needed
                Cancion cancion = construirCancionDesdeResultSet(rs);
                canciones.add(cancion);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.of(canciones);
    }

    @Override
    public Optional<List<Cancion>> todasCancionPorAutor(String autor) {
        List<Cancion> canciones = new ArrayList<>();
        String sql = "SELECT * FROM cancion WHERE artista = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, autor);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                // Process each row as needed
                Cancion cancion = construirCancionDesdeResultSet(rs);
                canciones.add(cancion);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.of(canciones);
    }

    @Override
    public Optional<Cancion> cancionPorTitulo(String titulo) {
        String sql = "SELECT * FROM cancion WHERE titulo = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, titulo);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                // Process the result set
                Cancion cancion = construirCancionDesdeResultSet(rs);
                return Optional.of(cancion);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }

    @Override
    public Optional<List<Cancion>> cancionDisponiblePorTitulo(String tituloCancion) {
        // This method might not be applicable for songs, but you can adjust it according to your needs
        List<Cancion> canciones = new ArrayList<>();
        String sql = "SELECT * FROM cancion WHERE titulo = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, tituloCancion);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                // Process each row as needed
                Cancion cancion = construirCancionDesdeResultSet(rs);
                canciones.add(cancion);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.of(canciones);
    }

    @Override
    public Optional<List<Cancion>> cancionDisponiblePorAutor(String nombreAutor) {
        // This method might not be applicable for songs, but you can adjust it according to your needs
        List<Cancion> canciones = new ArrayList<>();
        String sql = "SELECT * FROM cancion WHERE artista = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, nombreAutor);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                // Process each row as needed
                Cancion cancion = construirCancionDesdeResultSet(rs);
                canciones.add(cancion);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.of(canciones);
    }

    @Override
    public boolean guardarCancion(Cancion nuevaCancion) {
        String sql = "INSERT INTO cancion (id, artista, duracion) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, nuevaCancion.getId());
            pstmt.setString(2, nuevaCancion.getArtista());
            pstmt.setTime(3, nuevaCancion.getDuracion());

            int filasAfectadas = pstmt.executeUpdate();

            return filasAfectadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean eliminarCancion(String tituloCancion) {
        String sql = "DELETE FROM cancion WHERE titulo = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, tituloCancion);
            int filasAfectadas = pstmt.executeUpdate();
            return filasAfectadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean actualizarCancion(Cancion cancion) {
        String sql = "UPDATE cancion SET titulo = ?, artista = ?, duracion = ? WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(2, cancion.getArtista());
            pstmt.setTime(3, cancion.getDuracion());
            pstmt.setString(4, cancion.getId());

            int filasAfectadas = pstmt.executeUpdate();
            return filasAfectadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private Cancion construirCancionDesdeResultSet(ResultSet rs) throws SQLException {
        String id = rs.getString("id");
        String artista = rs.getString("artista");
        Time duracion = rs.getTime("duracion");
        return new Cancion(id, rs.getString("titulo"), 0, 0, 0, null, artista, duracion);
    }
}
