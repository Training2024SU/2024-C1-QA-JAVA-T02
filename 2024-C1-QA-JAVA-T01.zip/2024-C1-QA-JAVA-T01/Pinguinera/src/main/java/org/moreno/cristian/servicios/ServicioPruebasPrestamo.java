package org.moreno.cristian.servicios;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

public class ServicioPruebasPrestamo {
    private static final Logger log = Logger.getLogger(ServicioPruebasPrestamo.class.getName());

    // Mapa para almacenar la cantidad de ejemplares prestados por publicación
    private final Map<String, Integer> ejemplaresPrestadosPorPublicacion = new HashMap<>();

    // Mapa para almacenar la cantidad de ejemplares disponibles por publicación
    private final Map<String, Integer> ejemplaresDisponiblesPorPublicacion = new HashMap<>();

    // Método para realizar pruebas de préstamo
    public void realizarPruebas(String idPublicacion, String idUsuario, int ejemplaresPrestados) {
        // Simular el préstamo descontando los ejemplares prestados
        int ejemplaresDisponibles = ejemplaresDisponiblesPorPublicacion.getOrDefault(idPublicacion, 0);
        if (ejemplaresDisponibles >= ejemplaresPrestados) {
            ejemplaresPrestadosPorPublicacion.put(idPublicacion, ejemplaresPrestados);
            ejemplaresDisponiblesPorPublicacion.put(idPublicacion, ejemplaresDisponibles - ejemplaresPrestados);
            log.info("Préstamo realizado con éxito: {} ejemplares prestados de la publicación {} al usuario {}"
            );
        } else {
            log.warning("No hay suficientes ejemplares disponibles para el préstamo");
        }
    }

    // Método para obtener la cantidad de ejemplares descontados durante la prueba
    public int obtenerEjemplaresDescontados(String idPublicacion, int ejemplaresPrestados) {
        return ejemplaresPrestadosPorPublicacion.getOrDefault(idPublicacion, 0);
    }

    // Método para obtener la cantidad de ejemplares disponibles después de la prueba de préstamo
    public int obtenerEjemplaresDisponibles(String idPublicacion) {
        return ejemplaresDisponiblesPorPublicacion.getOrDefault(idPublicacion, 0);
    }

    // Método para agregar ejemplares disponibles para una publicación
    public void agregarEjemplares(String idPublicacion, int cantidad) {
        int ejemplaresDisponibles = ejemplaresDisponiblesPorPublicacion.getOrDefault(idPublicacion, 0);
        ejemplaresDisponiblesPorPublicacion.put(idPublicacion, ejemplaresDisponibles + cantidad);
        log.info("{} ejemplares agregados a la publicación {}");
    }

    public void realizarPrestamo(String idPublicacion, String idUsuario, int ejemplaresPrestados) {
    }
}

