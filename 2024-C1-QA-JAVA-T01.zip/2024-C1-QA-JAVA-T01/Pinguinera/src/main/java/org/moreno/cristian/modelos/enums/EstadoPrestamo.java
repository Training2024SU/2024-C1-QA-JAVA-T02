package org.moreno.cristian.modelos.enums;

public enum EstadoPrestamo {
    SOLICITADO,
    REALIZADO,
    FINALIZADO
}
