package org.moreno.cristian.repositorios;

import org.moreno.cristian.modelos.Cancion;

import java.util.List;
import java.util.Optional;
import org.moreno.cristian.modelos.Ensayo;

public interface RepositorioEnsayo {
    Optional<List<Ensayo>> todasEnsayo();
    Optional<List<Ensayo>> todasEnsayoPorAutor(String autor);

    Optional<Ensayo> ensayoPorTitulo(String titulo);
    Optional<List<Ensayo>> ensayoDisponiblePorTitulo(String tituloEnsayo);
    Optional<List<Ensayo>> ensayoDisponiblePorAutor(String nombreAutor);

    boolean guardarEnsayo(Ensayo nuevaEnsayo);
    boolean eliminarEnsayo(String tituloEnsayo);
    boolean actualizarEnsayo(Ensayo ensayo);
}