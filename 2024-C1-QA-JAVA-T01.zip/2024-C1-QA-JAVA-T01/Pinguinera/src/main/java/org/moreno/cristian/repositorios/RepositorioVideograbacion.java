package org.moreno.cristian.repositorios;

import org.moreno.cristian.modelos.Videograbacion;

import java.util.List;
import java.util.Optional;

public interface RepositorioVideograbacion {
    Optional<List<Videograbacion>> todasVideograbaciones();
    Optional<List<Videograbacion>> todasVideograbacionesPorAutor(String autor);

    Optional<Videograbacion> videograbacionesPorTitulo(String titulo);
    Optional<List<Videograbacion>> videograbacionesDisponiblesPorTitulo(String tituloVideograbacion);
    Optional<List<Videograbacion>> videograbacionesDisponiblesPorAutor(String nombreAutor);

    boolean guardarVideograbacion(Videograbacion nuevaVideograbacion);
    boolean eliminarVideograbacion(String tituloVideograbacion);
    boolean actualizarVideograbacion(Videograbacion videograbacion);
}
