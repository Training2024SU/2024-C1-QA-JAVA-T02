package org.moreno.cristian.modelos.enums;

public enum TipoPublicacion {
    LIBRO,
    NOVELA,
    VIDEOGRABACION,
    CANCION,
    ENSAYO
}
