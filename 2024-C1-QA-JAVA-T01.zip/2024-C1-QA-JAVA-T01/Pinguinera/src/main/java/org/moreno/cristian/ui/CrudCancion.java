package org.moreno.cristian.ui;

import org.moreno.cristian.servicios.ScannerUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Scanner;

public class CrudCancion {

    private static final Logger log = LogManager.getLogger(CrudCancion.class);

    public static void iniciarCrudCancion() {
        Scanner scan = ScannerUtil.obtenerScanner();

        while (true) {
            log.info("\nOperaciones CRUD para Canciones:\n" +
                    "   1. Crear canción\n" +
                    "   2. Listar canciones\n" +
                    "   3. Actualizar canción\n" +
                    "   4. Eliminar canción\n" +
                    "   5. Volver al menú principal\n");

            String opcion = scan.nextLine();

            switch (opcion) {
                case "1":
                    // crearCanción();
                    break;
                case "2":
                    // listarCanción();
                    break;
                case "3":
                    // actualizarCanción();
                    break;
                case "4":
                    // eliminarCanción();
                    break;
                case "5":
                    return;
                default:
                    log.error("Opción no válida");
            }
        }
    }
}
