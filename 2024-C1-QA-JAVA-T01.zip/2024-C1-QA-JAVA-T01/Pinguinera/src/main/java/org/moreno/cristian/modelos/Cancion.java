package org.moreno.cristian.modelos;

import java.sql.Time;

public class Cancion extends Publicacion {
    private String artista;
    private Time duracion;

    public Cancion(String id, String titulo, int totalEjemplares, int ejemplaresPrestados, int ejemplaresDisponibles, Autor autor, String artista, Time duracion) {
        super(id, titulo, totalEjemplares, ejemplaresPrestados, ejemplaresDisponibles, autor);
        this.artista = artista;
        this.duracion = duracion;
    }

    public Cancion(String titulo, int totalEjemplares, int ejemplaresDisponibles, int ejemplaresPrestados, Autor autor, String artista, Time duracion) {
        super(titulo, totalEjemplares, ejemplaresDisponibles, ejemplaresPrestados, autor);
        this.artista = artista;
        this.duracion = duracion;
    }

    // Getters y setters
    public String getArtista() {
        return artista;
    }

    public void setArtista(String artista) {
        this.artista = artista;
    }

    public Time getDuracion() {
        return duracion;
    }

    public void setDuracion(Time duracion) {
        this.duracion = duracion;
    }
}
