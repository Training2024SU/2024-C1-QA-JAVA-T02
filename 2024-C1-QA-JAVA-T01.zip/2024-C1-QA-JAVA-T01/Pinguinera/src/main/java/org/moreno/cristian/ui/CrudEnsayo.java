package org.moreno.cristian.ui;


import org.moreno.cristian.servicios.ScannerUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Scanner;

public class CrudEnsayo {

    private static final Logger log = LogManager.getLogger(CrudEnsayo.class);

    public static void iniciarCrudEnsayo() {
        Scanner scan = ScannerUtil.obtenerScanner();

        while (true) {
            log.info("\nOperaciones CRUD para Ensayos:\n" +
                    "   1. Crear ensayo\n" +
                    "   2. Listar ensayos\n" +
                    "   3. Actualizar ensayo\n" +
                    "   4. Eliminar ensayo\n" +
                    "   5. Volver al menú principal\n");

            String opcion = scan.nextLine();

            switch (opcion) {
                case "1":
                    // crearEnsayo();
                    break;
                case "2":
                    // listarEnsayos();
                    break;
                case "3":
                    // actualizarEnsayo();
                    break;
                case "4":
                    // eliminarEnsayo();
                    break;
                case "5":
                    return;
                default:
                    log.error("Opción no válida");
            }
        }
    }
}
