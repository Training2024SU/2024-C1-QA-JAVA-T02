package org.moreno.cristian.ui;

import org.moreno.cristian.servicios.ScannerUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Scanner;

public class CrudVideograbacion {

    private static final Logger log = LogManager.getLogger(CrudVideograbacion.class);

    public static void iniciarCrudVideograbacion() {
        Scanner scan = ScannerUtil.obtenerScanner();

        while (true) {
            log.info("\nOperaciones CRUD para Videograbaciones:\n" +
                    "   1. Crear videograbación\n" +
                    "   2. Listar videograbaciones\n" +
                    "   3. Actualizar videograbación\n" +
                    "   4. Eliminar videograbación\n" +
                    "   5. Volver al menú principal\n");

            String opcion = scan.nextLine();

            switch (opcion) {
                case "1":
                    // crearVideograbacion();
                    break;
                case "2":
                    // listarVideograbaciones();
                    break;
                case "3":
                    // actualizarVideograbacion();
                    break;
                case "4":
                    // eliminarVideograbacion();
                    break;
                case "5":
                    return;
                default:
                    log.error("Opción no válida");
            }
        }
    }

    // Define o importa los métodos necesarios aquí
}

