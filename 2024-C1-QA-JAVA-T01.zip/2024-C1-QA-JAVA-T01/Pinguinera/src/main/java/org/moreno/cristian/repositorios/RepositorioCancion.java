package org.moreno.cristian.repositorios;

import org.moreno.cristian.modelos.Videograbacion;

import java.util.List;
import java.util.Optional;
import org.moreno.cristian.modelos.Cancion;

import java.util.List;
import java.util.Optional;

public interface RepositorioCancion {
    Optional<List<Cancion>> todasCancion();
    Optional<List<Cancion>> todasCancionPorAutor(String autor);

    Optional<Cancion> cancionPorTitulo(String titulo);
    Optional<List<Cancion>> cancionDisponiblePorTitulo(String tituloVideograbacion);
    Optional<List<Cancion>> cancionDisponiblePorAutor(String nombreAutor);

    boolean guardarCancion(Cancion nuevaCancion);
    boolean eliminarCancion(String tituloCancion);
    boolean actualizarCancion(Cancion cancion);
}

